# Hoare-Style Reasoning with (Algebraic) Continuations
------------------------------------------------------

This directory contains the Coq/SSreflect files associated with the
ICFP'13 paper "Hoare-Style Reasoning with (Algebraic) Continuations"
by Germ&aacute;n Delbianco and Aleks Nanevski.

The files develop the implementation of HTTcc, using SSreflect 1.6.2
over Coq 8.7. We present the proofs for the examples presented in the
paper, as well as some other typical examples.

## REQUIREMENTS

Coq 8.7
	
	http://coq.inria.fr/

MathComnp libraries v 1.6.2 :

	http://math-comp.github.io/math-comp/


**Installation using OPAM**

We suggest to install Coq and SSreflect's mathcomp libraries through the OPAM package managing system.

1. Add the Coq repositories.
	
		opam repo add coq-released https://coq.inria.fr/opam/released

2. Pin ssreflect to version v1.6.2.

		opam pin add coq-mathcomp-ssreflect v.1.6.2

This should do it. For further information or assitance compiling this files contact
Germ&aacute;n Andr&eacute;s Delbianco at _german.delbianco@imdea.org_.


***BUILD***

	make clean; make

## Contents

|File name           |  Description
|--------------------|-------------
| Makefile           | build file 
| _CoqProject        | Coq project file 
| README.md          | this file
||
| core	             |  *HTTC implementation*      
| core/callc.v       | Large-footprint shallow embedding for SK types
| core/srules.v      | Structural rules and bnd_x, val_x lemmas
||
| heaps	             | *HTT preliminaries*
||
| heaps/heaps.v      | A theory of heaps   
| heaps/hprop.v      | Heap PCM properties
| heaps/domains.v    | Domain Theory library
| heaps/finmap.v     | A theory of finite maps
| heaps/ordtype.v    | Ordered-types
| heaps/prelude.v    | HTT preliminaries
| heaps/rels.v       | big Preds
| heaps/relt.v       | "  "
|| 
| examples               |  *Examples*
||
| examples/incr3.v       | Incr3 example from Sections 2 and 3
| examples/rember.v      | rember-up-to-last from Section 6.1
| examples/pingpong.v    | Ping-Pong from Section 6.2
| examples/jumpswap.v    | Experiments comparing throw vs. abort
| examples/handler.v     | Implements Error handlers using finalisation code
| examples/escape.v      | Escape from loops using throw
| examples/funclosures.v | More upward-continuations using closures examples 
| examples/noloop.v      | Misc. downward-continuation examples
||
| noanalgebraic            | *Alternative non-algebraic model*
||
| noanalgebraic/callcWH.v  | Large-footprint embedding for SK types
| noanalgebraic/srulesWH.v | Structural rules and bnd_x, val_x lemmas.
||
| nonalgebraic/throwpong.v | Implements Ping-Pong example (Section 6.2), adapted to    							  the non algebraic setting
| nonalgebraic/incr3na.v   | Idem for incr3 (Example 3)
| nonalgebraic/swap.v      | Modelling abort's behaviour using throw.
